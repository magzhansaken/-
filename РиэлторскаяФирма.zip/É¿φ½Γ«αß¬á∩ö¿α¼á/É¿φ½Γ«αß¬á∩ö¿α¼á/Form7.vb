﻿Public Class Form7
    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "РиелторскаяФирмаDataSet.Покупатели". При необходимости она может быть перемещена или удалена.
        Me.ПокупателиTableAdapter.Fill(Me.РиелторскаяФирмаDataSet.Покупатели)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class