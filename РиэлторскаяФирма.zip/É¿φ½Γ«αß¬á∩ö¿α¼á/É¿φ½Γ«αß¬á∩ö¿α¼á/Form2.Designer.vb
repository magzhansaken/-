﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim КодВидаLabel As System.Windows.Forms.Label
        Dim НаименованиеLabel As System.Windows.Forms.Label
        Dim ОписаниеLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.РиелторскаяФирмаDataSet = New РиэлторскаяФирма.РиелторскаяФирмаDataSet()
        Me.ВидыКвартирBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ВидыКвартирTableAdapter = New РиэлторскаяФирма.РиелторскаяФирмаDataSetTableAdapters.ВидыКвартирTableAdapter()
        Me.TableAdapterManager = New РиэлторскаяФирма.РиелторскаяФирмаDataSetTableAdapters.TableAdapterManager()
        Me.ВидыКвартирBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ВидыКвартирBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.КодВидаTextBox = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        КодВидаLabel = New System.Windows.Forms.Label()
        НаименованиеLabel = New System.Windows.Forms.Label()
        ОписаниеLabel = New System.Windows.Forms.Label()
        CType(Me.РиелторскаяФирмаDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ВидыКвартирBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ВидыКвартирBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ВидыКвартирBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'КодВидаLabel
        '
        КодВидаLabel.AutoSize = True
        КодВидаLabel.Location = New System.Drawing.Point(107, 131)
        КодВидаLabel.Name = "КодВидаLabel"
        КодВидаLabel.Size = New System.Drawing.Size(57, 13)
        КодВидаLabel.TabIndex = 2
        КодВидаLabel.Text = "Код Вида:"
        '
        'НаименованиеLabel
        '
        НаименованиеLabel.AutoSize = True
        НаименованиеLabel.Location = New System.Drawing.Point(78, 81)
        НаименованиеLabel.Name = "НаименованиеLabel"
        НаименованиеLabel.Size = New System.Drawing.Size(86, 13)
        НаименованиеLabel.TabIndex = 4
        НаименованиеLabel.Text = "Наименование:"
        '
        'ОписаниеLabel
        '
        ОписаниеLabel.AutoSize = True
        ОписаниеLabel.Location = New System.Drawing.Point(44, 212)
        ОписаниеLabel.Name = "ОписаниеLabel"
        ОписаниеLabel.Size = New System.Drawing.Size(60, 13)
        ОписаниеLabel.TabIndex = 6
        ОписаниеLabel.Text = "Описание:"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(48, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(260, 23)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Таблица ""ВидыКвартир"""
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'РиелторскаяФирмаDataSet
        '
        Me.РиелторскаяФирмаDataSet.DataSetName = "РиелторскаяФирмаDataSet"
        Me.РиелторскаяФирмаDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ВидыКвартирBindingSource
        '
        Me.ВидыКвартирBindingSource.DataMember = "ВидыКвартир"
        Me.ВидыКвартирBindingSource.DataSource = Me.РиелторскаяФирмаDataSet
        '
        'ВидыКвартирTableAdapter
        '
        Me.ВидыКвартирTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.UpdateOrder = РиэлторскаяФирма.РиелторскаяФирмаDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.ВидыКвартирTableAdapter = Me.ВидыКвартирTableAdapter
        Me.TableAdapterManager.ВидыУслугTableAdapter = Nothing
        Me.TableAdapterManager.ДоговорыTableAdapter = Nothing
        Me.TableAdapterManager.ДолжностиTableAdapter = Nothing
        Me.TableAdapterManager.Покупатели2TableAdapter = Nothing
        Me.TableAdapterManager.ПокупателиTableAdapter = Nothing
        Me.TableAdapterManager.ПродавцыTableAdapter = Nothing
        Me.TableAdapterManager.СотрудникиTableAdapter = Nothing
        '
        'ВидыКвартирBindingNavigator
        '
        Me.ВидыКвартирBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.ВидыКвартирBindingNavigator.BindingSource = Me.ВидыКвартирBindingSource
        Me.ВидыКвартирBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.ВидыКвартирBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.ВидыКвартирBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.ВидыКвартирBindingNavigatorSaveItem})
        Me.ВидыКвартирBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.ВидыКвартирBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.ВидыКвартирBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.ВидыКвартирBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.ВидыКвартирBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.ВидыКвартирBindingNavigator.Name = "ВидыКвартирBindingNavigator"
        Me.ВидыКвартирBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.ВидыКвартирBindingNavigator.Size = New System.Drawing.Size(351, 25)
        Me.ВидыКвартирBindingNavigator.TabIndex = 2
        Me.ВидыКвартирBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Добавить"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(43, 22)
        Me.BindingNavigatorCountItem.Text = "для {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Общее число элементов"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Удалить"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Переместить в начало"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Переместить назад"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Положение"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Текущее положение"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Переместить вперед"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Переместить в конец"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ВидыКвартирBindingNavigatorSaveItem
        '
        Me.ВидыКвартирBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ВидыКвартирBindingNavigatorSaveItem.Image = CType(resources.GetObject("ВидыКвартирBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.ВидыКвартирBindingNavigatorSaveItem.Name = "ВидыКвартирBindingNavigatorSaveItem"
        Me.ВидыКвартирBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.ВидыКвартирBindingNavigatorSaveItem.Text = "Сохранить данные"
        '
        'КодВидаTextBox
        '
        Me.КодВидаTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ВидыКвартирBindingSource, "КодВида", True))
        Me.КодВидаTextBox.Location = New System.Drawing.Point(170, 128)
        Me.КодВидаTextBox.Name = "КодВидаTextBox"
        Me.КодВидаTextBox.Size = New System.Drawing.Size(100, 20)
        Me.КодВидаTextBox.TabIndex = 3
        '
        'ComboBox1
        '
        Me.ComboBox1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.ВидыКвартирBindingSource, "КодВида", True))
        Me.ComboBox1.DataSource = Me.ВидыКвартирBindingSource
        Me.ComboBox1.DisplayMember = "Наименование"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(170, 78)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 8
        Me.ComboBox1.ValueMember = "КодВида"
        '
        'ComboBox2
        '
        Me.ComboBox2.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.ВидыКвартирBindingSource, "КодВида", True))
        Me.ComboBox2.DataSource = Me.ВидыКвартирBindingSource
        Me.ComboBox2.DisplayMember = "Описание"
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(110, 204)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(198, 21)
        Me.ComboBox2.TabIndex = 9
        Me.ComboBox2.ValueMember = "КодВида"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(351, 311)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(ОписаниеLabel)
        Me.Controls.Add(НаименованиеLabel)
        Me.Controls.Add(КодВидаLabel)
        Me.Controls.Add(Me.КодВидаTextBox)
        Me.Controls.Add(Me.ВидыКвартирBindingNavigator)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form2"
        Me.Text = "Таблица ""ВидыКвартир"""
        CType(Me.РиелторскаяФирмаDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ВидыКвартирBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ВидыКвартирBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ВидыКвартирBindingNavigator.ResumeLayout(False)
        Me.ВидыКвартирBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents РиелторскаяФирмаDataSet As РиелторскаяФирмаDataSet
    Friend WithEvents ВидыКвартирBindingSource As BindingSource
    Friend WithEvents ВидыКвартирTableAdapter As РиелторскаяФирмаDataSetTableAdapters.ВидыКвартирTableAdapter
    Friend WithEvents TableAdapterManager As РиелторскаяФирмаDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ВидыКвартирBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents ВидыКвартирBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents КодВидаTextBox As TextBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
End Class
