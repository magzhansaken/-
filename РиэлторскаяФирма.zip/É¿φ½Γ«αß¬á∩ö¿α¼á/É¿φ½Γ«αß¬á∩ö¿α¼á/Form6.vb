﻿Public Class Form6
    Private Sub Покупатели2BindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles Покупатели2BindingNavigatorSaveItem.Click
        Me.Validate()
        Me.Покупатели2BindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.РиелторскаяФирмаDataSet)

    End Sub

    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "РиелторскаяФирмаDataSet.Покупатели2". При необходимости она может быть перемещена или удалена.
        Me.Покупатели2TableAdapter.Fill(Me.РиелторскаяФирмаDataSet.Покупатели2)

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        Button1.Enabled = True

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Col As System.Windows.Forms.DataGridViewColumn
        Select Case ListBox1.SelectedIndex
            Case 0
                Col = DataGridViewTextBoxColumn3
            Case 1
                Col = DataGridViewTextBoxColumn4
            Case 2
                Col = DataGridViewTextBoxColumn5
            Case 3
                Col = DataGridViewTextBoxColumn6
            Case 4
                Col = DataGridViewTextBoxColumn7
            Case 5
                Col = DataGridViewTextBoxColumn8
            Case 6
                Col = DataGridViewTextBoxColumn9
            Case 7
                Col = DataGridViewTextBoxColumn10
            Case 8
                Col = DataGridViewTextBoxColumn11
            Case 9
                Col = DataGridViewTextBoxColumn12
        End Select
        If RadioButton1.Checked Then
            Покупатели2DataGridView.Sort(Col, System.ComponentModel.ListSortDirection.Ascending)
        Else
            Покупатели2DataGridView.Sort(Col, System.ComponentModel.ListSortDirection.Descending)
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Покупатели2BindingSource.Filter = "ФИО='" & ComboBox1.Text & "'"
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Покупатели2BindingSource.Filter = ""

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        For i = 0 To Покупатели2DataGridView.ColumnCount - 1
            For j = 0 To Покупатели2DataGridView.RowCount - 1
                Покупатели2DataGridView.Item(i, j).Style.BackColor = Color.White
                Покупатели2DataGridView.Item(i, j).Style.BackColor = Color.Black
            Next j
        Next i
        For i = 0 To Покупатели2DataGridView.ColumnCount - 1
            For j = 0 To Покупатели2DataGridView.RowCount - 1
                If InStr(Покупатели2DataGridView.Item(i, j).Value, TextBox1.Text) Then
                    Покупатели2DataGridView.Item(i, j).Style.BackColor = Color.AliceBlue
                    Покупатели2DataGridView.Item(i, j).Style.BackColor = Color.Blue
                End If
            Next j
        Next i
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.Close()
    End Sub
End Class