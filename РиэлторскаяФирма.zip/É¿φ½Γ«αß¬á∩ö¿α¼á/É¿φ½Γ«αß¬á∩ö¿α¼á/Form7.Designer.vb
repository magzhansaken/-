﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form7
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.РиелторскаяФирмаDataSet = New РиэлторскаяФирма.РиелторскаяФирмаDataSet()
        Me.ПокупателиBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ПокупателиTableAdapter = New РиэлторскаяФирма.РиелторскаяФирмаDataSetTableAdapters.ПокупателиTableAdapter()
        CType(Me.РиелторскаяФирмаDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ПокупателиBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ReportViewer1
        '
        Me.ReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource1.Name = "DataSet1"
        ReportDataSource1.Value = Me.ПокупателиBindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource1)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "РиэлторскаяФирма.Report1.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(504, 335)
        Me.ReportViewer1.TabIndex = 0
        '
        'РиелторскаяФирмаDataSet
        '
        Me.РиелторскаяФирмаDataSet.DataSetName = "РиелторскаяФирмаDataSet"
        Me.РиелторскаяФирмаDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ПокупателиBindingSource
        '
        Me.ПокупателиBindingSource.DataMember = "Покупатели"
        Me.ПокупателиBindingSource.DataSource = Me.РиелторскаяФирмаDataSet
        '
        'ПокупателиTableAdapter
        '
        Me.ПокупателиTableAdapter.ClearBeforeFill = True
        '
        'Form7
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(504, 335)
        Me.Controls.Add(Me.ReportViewer1)
        Me.Name = "Form7"
        Me.Text = "Отчет Таблицы ""Покупатели"""
        CType(Me.РиелторскаяФирмаDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ПокупателиBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents ПокупателиBindingSource As BindingSource
    Friend WithEvents РиелторскаяФирмаDataSet As РиелторскаяФирмаDataSet
    Friend WithEvents ПокупателиTableAdapter As РиелторскаяФирмаDataSetTableAdapters.ПокупателиTableAdapter
End Class
