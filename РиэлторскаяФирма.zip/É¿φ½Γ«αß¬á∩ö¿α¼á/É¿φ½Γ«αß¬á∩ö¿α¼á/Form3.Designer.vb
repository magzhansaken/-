﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ФИОLabel As System.Windows.Forms.Label
        Dim ПолLabel As System.Windows.Forms.Label
        Dim ДатаРожденияLabel As System.Windows.Forms.Label
        Dim АдресПроживанияLabel As System.Windows.Forms.Label
        Dim ТелефонLabel As System.Windows.Forms.Label
        Dim ПаспортныеданныеLabel As System.Windows.Forms.Label
        Dim КодВидаКвартирыLabel As System.Windows.Forms.Label
        Dim КоличествоКомнатLabel As System.Windows.Forms.Label
        Dim ПлощадьLabel As System.Windows.Forms.Label
        Dim ОтметкаОРаздельномСанузлеLabel As System.Windows.Forms.Label
        Dim ОтметкаОНаличииТелефонаLabel As System.Windows.Forms.Label
        Dim ЦенаLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.РиелторскаяФирмаDataSet = New РиэлторскаяФирма.РиелторскаяФирмаDataSet()
        Me.Покупатели2BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Покупатели2TableAdapter = New РиэлторскаяФирма.РиелторскаяФирмаDataSetTableAdapters.Покупатели2TableAdapter()
        Me.TableAdapterManager = New РиэлторскаяФирма.РиелторскаяФирмаDataSetTableAdapters.TableAdapterManager()
        Me.Покупатели2BindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.Покупатели2BindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ФИОTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ДатаРожденияDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.АдресПроживанияTextBox = New System.Windows.Forms.TextBox()
        Me.ТелефонTextBox = New System.Windows.Forms.TextBox()
        Me.ПаспортныеданныеTextBox = New System.Windows.Forms.TextBox()
        Me.КоличествоКомнатTextBox = New System.Windows.Forms.TextBox()
        Me.ПлощадьTextBox = New System.Windows.Forms.TextBox()
        Me.ОтметкаОРаздельномСанузлеCheckBox = New System.Windows.Forms.CheckBox()
        Me.ОтметкаОНаличииТелефонаCheckBox = New System.Windows.Forms.CheckBox()
        Me.ЦенаTextBox = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        ФИОLabel = New System.Windows.Forms.Label()
        ПолLabel = New System.Windows.Forms.Label()
        ДатаРожденияLabel = New System.Windows.Forms.Label()
        АдресПроживанияLabel = New System.Windows.Forms.Label()
        ТелефонLabel = New System.Windows.Forms.Label()
        ПаспортныеданныеLabel = New System.Windows.Forms.Label()
        КодВидаКвартирыLabel = New System.Windows.Forms.Label()
        КоличествоКомнатLabel = New System.Windows.Forms.Label()
        ПлощадьLabel = New System.Windows.Forms.Label()
        ОтметкаОРаздельномСанузлеLabel = New System.Windows.Forms.Label()
        ОтметкаОНаличииТелефонаLabel = New System.Windows.Forms.Label()
        ЦенаLabel = New System.Windows.Forms.Label()
        CType(Me.РиелторскаяФирмаDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Покупатели2BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Покупатели2BindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Покупатели2BindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'ФИОLabel
        '
        ФИОLabel.AutoSize = True
        ФИОLabel.Location = New System.Drawing.Point(154, 63)
        ФИОLabel.Name = "ФИОLabel"
        ФИОLabel.Size = New System.Drawing.Size(37, 13)
        ФИОLabel.TabIndex = 1
        ФИОLabel.Text = "ФИО:"
        '
        'ПолLabel
        '
        ПолLabel.AutoSize = True
        ПолLabel.Location = New System.Drawing.Point(161, 89)
        ПолLabel.Name = "ПолLabel"
        ПолLabel.Size = New System.Drawing.Size(30, 13)
        ПолLabel.TabIndex = 4
        ПолLabel.Text = "Пол:"
        '
        'ДатаРожденияLabel
        '
        ДатаРожденияLabel.AutoSize = True
        ДатаРожденияLabel.Location = New System.Drawing.Point(101, 116)
        ДатаРожденияLabel.Name = "ДатаРожденияLabel"
        ДатаРожденияLabel.Size = New System.Drawing.Size(90, 13)
        ДатаРожденияLabel.TabIndex = 6
        ДатаРожденияLabel.Text = "Дата Рождения:"
        '
        'АдресПроживанияLabel
        '
        АдресПроживанияLabel.AutoSize = True
        АдресПроживанияLabel.Location = New System.Drawing.Point(83, 141)
        АдресПроживанияLabel.Name = "АдресПроживанияLabel"
        АдресПроживанияLabel.Size = New System.Drawing.Size(108, 13)
        АдресПроживанияLabel.TabIndex = 8
        АдресПроживанияLabel.Text = "Адрес Проживания:"
        '
        'ТелефонLabel
        '
        ТелефонLabel.AutoSize = True
        ТелефонLabel.Location = New System.Drawing.Point(136, 167)
        ТелефонLabel.Name = "ТелефонLabel"
        ТелефонLabel.Size = New System.Drawing.Size(55, 13)
        ТелефонLabel.TabIndex = 10
        ТелефонLabel.Text = "Телефон:"
        '
        'ПаспортныеданныеLabel
        '
        ПаспортныеданныеLabel.AutoSize = True
        ПаспортныеданныеLabel.Location = New System.Drawing.Point(80, 193)
        ПаспортныеданныеLabel.Name = "ПаспортныеданныеLabel"
        ПаспортныеданныеLabel.Size = New System.Drawing.Size(111, 13)
        ПаспортныеданныеLabel.TabIndex = 12
        ПаспортныеданныеLabel.Text = "Паспортныеданные:"
        '
        'КодВидаКвартирыLabel
        '
        КодВидаКвартирыLabel.AutoSize = True
        КодВидаКвартирыLabel.Location = New System.Drawing.Point(81, 219)
        КодВидаКвартирыLabel.Name = "КодВидаКвартирыLabel"
        КодВидаКвартирыLabel.Size = New System.Drawing.Size(110, 13)
        КодВидаКвартирыLabel.TabIndex = 14
        КодВидаКвартирыLabel.Text = "Код Вида Квартиры:"
        '
        'КоличествоКомнатLabel
        '
        КоличествоКомнатLabel.AutoSize = True
        КоличествоКомнатLabel.Location = New System.Drawing.Point(81, 245)
        КоличествоКомнатLabel.Name = "КоличествоКомнатLabel"
        КоличествоКомнатLabel.Size = New System.Drawing.Size(110, 13)
        КоличествоКомнатLabel.TabIndex = 16
        КоличествоКомнатLabel.Text = "Количество Комнат:"
        '
        'ПлощадьLabel
        '
        ПлощадьLabel.AutoSize = True
        ПлощадьLabel.Location = New System.Drawing.Point(134, 271)
        ПлощадьLabel.Name = "ПлощадьLabel"
        ПлощадьLabel.Size = New System.Drawing.Size(57, 13)
        ПлощадьLabel.TabIndex = 18
        ПлощадьLabel.Text = "Площадь:"
        '
        'ОтметкаОРаздельномСанузлеLabel
        '
        ОтметкаОРаздельномСанузлеLabel.AutoSize = True
        ОтметкаОРаздельномСанузлеLabel.Location = New System.Drawing.Point(18, 299)
        ОтметкаОРаздельномСанузлеLabel.Name = "ОтметкаОРаздельномСанузлеLabel"
        ОтметкаОРаздельномСанузлеLabel.Size = New System.Drawing.Size(173, 13)
        ОтметкаОРаздельномСанузлеLabel.TabIndex = 20
        ОтметкаОРаздельномСанузлеLabel.Text = "Отметка ОРаздельном Санузле:"
        '
        'ОтметкаОНаличииТелефонаLabel
        '
        ОтметкаОНаличииТелефонаLabel.AutoSize = True
        ОтметкаОНаличииТелефонаLabel.Location = New System.Drawing.Point(25, 329)
        ОтметкаОНаличииТелефонаLabel.Name = "ОтметкаОНаличииТелефонаLabel"
        ОтметкаОНаличииТелефонаLabel.Size = New System.Drawing.Size(162, 13)
        ОтметкаОНаличииТелефонаLabel.TabIndex = 22
        ОтметкаОНаличииТелефонаLabel.Text = "Отметка ОНаличии Телефона:"
        '
        'ЦенаLabel
        '
        ЦенаLabel.AutoSize = True
        ЦенаLabel.Location = New System.Drawing.Point(155, 357)
        ЦенаLabel.Name = "ЦенаLabel"
        ЦенаLabel.Size = New System.Drawing.Size(36, 13)
        ЦенаLabel.TabIndex = 24
        ЦенаLabel.Text = "Цена:"
        '
        'РиелторскаяФирмаDataSet
        '
        Me.РиелторскаяФирмаDataSet.DataSetName = "РиелторскаяФирмаDataSet"
        Me.РиелторскаяФирмаDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Покупатели2BindingSource
        '
        Me.Покупатели2BindingSource.DataMember = "Покупатели2"
        Me.Покупатели2BindingSource.DataSource = Me.РиелторскаяФирмаDataSet
        '
        'Покупатели2TableAdapter
        '
        Me.Покупатели2TableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.UpdateOrder = РиэлторскаяФирма.РиелторскаяФирмаDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.ВидыКвартирTableAdapter = Nothing
        Me.TableAdapterManager.ВидыУслугTableAdapter = Nothing
        Me.TableAdapterManager.ДоговорыTableAdapter = Nothing
        Me.TableAdapterManager.ДолжностиTableAdapter = Nothing
        Me.TableAdapterManager.Покупатели2TableAdapter = Me.Покупатели2TableAdapter
        Me.TableAdapterManager.ПокупателиTableAdapter = Nothing
        Me.TableAdapterManager.ПродавцыTableAdapter = Nothing
        Me.TableAdapterManager.СотрудникиTableAdapter = Nothing
        '
        'Покупатели2BindingNavigator
        '
        Me.Покупатели2BindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.Покупатели2BindingNavigator.BindingSource = Me.Покупатели2BindingSource
        Me.Покупатели2BindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.Покупатели2BindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.Покупатели2BindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.Покупатели2BindingNavigatorSaveItem})
        Me.Покупатели2BindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.Покупатели2BindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.Покупатели2BindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.Покупатели2BindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.Покупатели2BindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.Покупатели2BindingNavigator.Name = "Покупатели2BindingNavigator"
        Me.Покупатели2BindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.Покупатели2BindingNavigator.Size = New System.Drawing.Size(468, 25)
        Me.Покупатели2BindingNavigator.TabIndex = 0
        Me.Покупатели2BindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Добавить"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(43, 22)
        Me.BindingNavigatorCountItem.Text = "для {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Общее число элементов"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Удалить"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Переместить в начало"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Переместить назад"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Положение"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Текущее положение"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Переместить вперед"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Переместить в конец"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'Покупатели2BindingNavigatorSaveItem
        '
        Me.Покупатели2BindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Покупатели2BindingNavigatorSaveItem.Image = CType(resources.GetObject("Покупатели2BindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.Покупатели2BindingNavigatorSaveItem.Name = "Покупатели2BindingNavigatorSaveItem"
        Me.Покупатели2BindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.Покупатели2BindingNavigatorSaveItem.Text = "Сохранить данные"
        '
        'ФИОTextBox
        '
        Me.ФИОTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Покупатели2BindingSource, "ФИО", True))
        Me.ФИОTextBox.Location = New System.Drawing.Point(197, 60)
        Me.ФИОTextBox.Name = "ФИОTextBox"
        Me.ФИОTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ФИОTextBox.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(93, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(260, 23)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Таблица ""Покупатели"""
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ДатаРожденияDateTimePicker
        '
        Me.ДатаРожденияDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.Покупатели2BindingSource, "ДатаРождения", True))
        Me.ДатаРожденияDateTimePicker.Location = New System.Drawing.Point(197, 112)
        Me.ДатаРожденияDateTimePicker.Name = "ДатаРожденияDateTimePicker"
        Me.ДатаРожденияDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.ДатаРожденияDateTimePicker.TabIndex = 7
        '
        'АдресПроживанияTextBox
        '
        Me.АдресПроживанияTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Покупатели2BindingSource, "АдресПроживания", True))
        Me.АдресПроживанияTextBox.Location = New System.Drawing.Point(197, 138)
        Me.АдресПроживанияTextBox.Name = "АдресПроживанияTextBox"
        Me.АдресПроживанияTextBox.Size = New System.Drawing.Size(100, 20)
        Me.АдресПроживанияTextBox.TabIndex = 9
        '
        'ТелефонTextBox
        '
        Me.ТелефонTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Покупатели2BindingSource, "Телефон", True))
        Me.ТелефонTextBox.Location = New System.Drawing.Point(197, 164)
        Me.ТелефонTextBox.Name = "ТелефонTextBox"
        Me.ТелефонTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ТелефонTextBox.TabIndex = 11
        '
        'ПаспортныеданныеTextBox
        '
        Me.ПаспортныеданныеTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Покупатели2BindingSource, "Паспортныеданные", True))
        Me.ПаспортныеданныеTextBox.Location = New System.Drawing.Point(197, 190)
        Me.ПаспортныеданныеTextBox.Name = "ПаспортныеданныеTextBox"
        Me.ПаспортныеданныеTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ПаспортныеданныеTextBox.TabIndex = 13
        '
        'КоличествоКомнатTextBox
        '
        Me.КоличествоКомнатTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Покупатели2BindingSource, "КоличествоКомнат", True))
        Me.КоличествоКомнатTextBox.Location = New System.Drawing.Point(197, 242)
        Me.КоличествоКомнатTextBox.Name = "КоличествоКомнатTextBox"
        Me.КоличествоКомнатTextBox.Size = New System.Drawing.Size(100, 20)
        Me.КоличествоКомнатTextBox.TabIndex = 17
        '
        'ПлощадьTextBox
        '
        Me.ПлощадьTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Покупатели2BindingSource, "Площадь", True))
        Me.ПлощадьTextBox.Location = New System.Drawing.Point(197, 268)
        Me.ПлощадьTextBox.Name = "ПлощадьTextBox"
        Me.ПлощадьTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ПлощадьTextBox.TabIndex = 19
        '
        'ОтметкаОРаздельномСанузлеCheckBox
        '
        Me.ОтметкаОРаздельномСанузлеCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.Покупатели2BindingSource, "ОтметкаОРаздельномСанузле", True))
        Me.ОтметкаОРаздельномСанузлеCheckBox.Location = New System.Drawing.Point(197, 294)
        Me.ОтметкаОРаздельномСанузлеCheckBox.Name = "ОтметкаОРаздельномСанузлеCheckBox"
        Me.ОтметкаОРаздельномСанузлеCheckBox.Size = New System.Drawing.Size(104, 24)
        Me.ОтметкаОРаздельномСанузлеCheckBox.TabIndex = 21
        Me.ОтметкаОРаздельномСанузлеCheckBox.UseVisualStyleBackColor = True
        '
        'ОтметкаОНаличииТелефонаCheckBox
        '
        Me.ОтметкаОНаличииТелефонаCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.Покупатели2BindingSource, "ОтметкаОНаличииТелефона", True))
        Me.ОтметкаОНаличииТелефонаCheckBox.Location = New System.Drawing.Point(197, 324)
        Me.ОтметкаОНаличииТелефонаCheckBox.Name = "ОтметкаОНаличииТелефонаCheckBox"
        Me.ОтметкаОНаличииТелефонаCheckBox.Size = New System.Drawing.Size(104, 24)
        Me.ОтметкаОНаличииТелефонаCheckBox.TabIndex = 23
        Me.ОтметкаОНаличииТелефонаCheckBox.UseVisualStyleBackColor = True
        '
        'ЦенаTextBox
        '
        Me.ЦенаTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Покупатели2BindingSource, "Цена", True))
        Me.ЦенаTextBox.Location = New System.Drawing.Point(197, 354)
        Me.ЦенаTextBox.Name = "ЦенаTextBox"
        Me.ЦенаTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ЦенаTextBox.TabIndex = 25
        '
        'ComboBox1
        '
        Me.ComboBox1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.Покупатели2BindingSource, "КодПокупателя", True))
        Me.ComboBox1.DataSource = Me.Покупатели2BindingSource
        Me.ComboBox1.DisplayMember = "Пол"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(197, 86)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 26
        Me.ComboBox1.ValueMember = "КодПокупателя"
        '
        'ComboBox2
        '
        Me.ComboBox2.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.Покупатели2BindingSource, "КодПокупателя", True))
        Me.ComboBox2.DataSource = Me.Покупатели2BindingSource
        Me.ComboBox2.DisplayMember = "ДополнительнаяИнформация"
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(197, 216)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 27
        Me.ComboBox2.ValueMember = "КодПокупателя"
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(195, 438)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(98, 23)
        Me.Button7.TabIndex = 34
        Me.Button7.Text = "Сохранить"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(299, 409)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(97, 23)
        Me.Button6.TabIndex = 33
        Me.Button6.Text = "Удалить"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(195, 409)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(98, 23)
        Me.Button5.TabIndex = 32
        Me.Button5.Text = "Слудущая"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(91, 409)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(98, 23)
        Me.Button4.TabIndex = 31
        Me.Button4.Text = "Последняя"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(299, 380)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(98, 23)
        Me.Button3.TabIndex = 30
        Me.Button3.Text = "Добавить"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(91, 380)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(98, 23)
        Me.Button2.TabIndex = 29
        Me.Button2.Text = "Предидущая"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(195, 380)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(98, 23)
        Me.Button1.TabIndex = 28
        Me.Button1.Text = "Первая"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(91, 438)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(96, 23)
        Me.Button8.TabIndex = 35
        Me.Button8.Text = "Таблица"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(299, 438)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(97, 23)
        Me.Button9.TabIndex = 36
        Me.Button9.Text = "Отчет"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(468, 467)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(ЦенаLabel)
        Me.Controls.Add(Me.ЦенаTextBox)
        Me.Controls.Add(ОтметкаОНаличииТелефонаLabel)
        Me.Controls.Add(Me.ОтметкаОНаличииТелефонаCheckBox)
        Me.Controls.Add(ОтметкаОРаздельномСанузлеLabel)
        Me.Controls.Add(Me.ОтметкаОРаздельномСанузлеCheckBox)
        Me.Controls.Add(ПлощадьLabel)
        Me.Controls.Add(Me.ПлощадьTextBox)
        Me.Controls.Add(КоличествоКомнатLabel)
        Me.Controls.Add(Me.КоличествоКомнатTextBox)
        Me.Controls.Add(КодВидаКвартирыLabel)
        Me.Controls.Add(ПаспортныеданныеLabel)
        Me.Controls.Add(Me.ПаспортныеданныеTextBox)
        Me.Controls.Add(ТелефонLabel)
        Me.Controls.Add(Me.ТелефонTextBox)
        Me.Controls.Add(АдресПроживанияLabel)
        Me.Controls.Add(Me.АдресПроживанияTextBox)
        Me.Controls.Add(ДатаРожденияLabel)
        Me.Controls.Add(Me.ДатаРожденияDateTimePicker)
        Me.Controls.Add(ПолLabel)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(ФИОLabel)
        Me.Controls.Add(Me.ФИОTextBox)
        Me.Controls.Add(Me.Покупатели2BindingNavigator)
        Me.Name = "Form3"
        Me.Text = "Таблица ""Покупатели"""
        CType(Me.РиелторскаяФирмаDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Покупатели2BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Покупатели2BindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Покупатели2BindingNavigator.ResumeLayout(False)
        Me.Покупатели2BindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents РиелторскаяФирмаDataSet As РиелторскаяФирмаDataSet
    Friend WithEvents Покупатели2BindingSource As BindingSource
    Friend WithEvents Покупатели2TableAdapter As РиелторскаяФирмаDataSetTableAdapters.Покупатели2TableAdapter
    Friend WithEvents TableAdapterManager As РиелторскаяФирмаDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Покупатели2BindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents Покупатели2BindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents ФИОTextBox As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents ДатаРожденияDateTimePicker As DateTimePicker
    Friend WithEvents АдресПроживанияTextBox As TextBox
    Friend WithEvents ТелефонTextBox As TextBox
    Friend WithEvents ПаспортныеданныеTextBox As TextBox
    Friend WithEvents КоличествоКомнатTextBox As TextBox
    Friend WithEvents ПлощадьTextBox As TextBox
    Friend WithEvents ОтметкаОРаздельномСанузлеCheckBox As CheckBox
    Friend WithEvents ОтметкаОНаличииТелефонаCheckBox As CheckBox
    Friend WithEvents ЦенаTextBox As TextBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
End Class
