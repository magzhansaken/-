﻿Public Class Form3
    Private Sub Покупатели2BindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles Покупатели2BindingNavigatorSaveItem.Click
        Me.Validate()
        Me.Покупатели2BindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.РиелторскаяФирмаDataSet)

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "РиелторскаяФирмаDataSet.Покупатели2". При необходимости она может быть перемещена или удалена.
        Me.Покупатели2TableAdapter.Fill(Me.РиелторскаяФирмаDataSet.Покупатели2)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Покупатели2BindingSource.MoveFirst()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Покупатели2BindingSource.MovePrevious()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Покупатели2BindingSource.AddNew()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Покупатели2BindingSource.MoveLast()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Покупатели2BindingSource.MoveNext()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Покупатели2BindingSource.RemoveCurrent()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Me.Validate()
        Me.Покупатели2BindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.РиелторскаяФирмаDataSet)
        Покупатели2BindingSource.MoveFirst()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Form6.Show()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Form7.Show()
    End Sub
End Class