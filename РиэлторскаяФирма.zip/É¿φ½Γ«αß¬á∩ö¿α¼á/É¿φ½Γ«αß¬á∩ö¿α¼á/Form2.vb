﻿Public Class Form2
    Private Sub ВидыКвартирBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ВидыКвартирBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ВидыКвартирBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.РиелторскаяФирмаDataSet)

    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "РиелторскаяФирмаDataSet.ВидыКвартир". При необходимости она может быть перемещена или удалена.
        Me.ВидыКвартирTableAdapter.Fill(Me.РиелторскаяФирмаDataSet.ВидыКвартир)

    End Sub
End Class