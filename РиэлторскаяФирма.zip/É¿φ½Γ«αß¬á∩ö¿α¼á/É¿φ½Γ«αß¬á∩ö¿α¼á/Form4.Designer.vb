﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim НаимДолжностиLabel As System.Windows.Forms.Label
        Dim ОбязанностиLabel As System.Windows.Forms.Label
        Dim ТребованияLabel As System.Windows.Forms.Label
        Dim КодДолжностиLabel As System.Windows.Forms.Label
        Dim ОкладLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.РиелторскаяФирмаDataSet = New РиэлторскаяФирма.РиелторскаяФирмаDataSet()
        Me.ДолжностиBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ДолжностиTableAdapter = New РиэлторскаяФирма.РиелторскаяФирмаDataSetTableAdapters.ДолжностиTableAdapter()
        Me.TableAdapterManager = New РиэлторскаяФирма.РиелторскаяФирмаDataSetTableAdapters.TableAdapterManager()
        Me.ДолжностиBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ДолжностиBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ОбязанностиTextBox = New System.Windows.Forms.TextBox()
        Me.ТребованияTextBox = New System.Windows.Forms.TextBox()
        Me.КодДолжностиTextBox = New System.Windows.Forms.TextBox()
        Me.ОкладTextBox = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        НаимДолжностиLabel = New System.Windows.Forms.Label()
        ОбязанностиLabel = New System.Windows.Forms.Label()
        ТребованияLabel = New System.Windows.Forms.Label()
        КодДолжностиLabel = New System.Windows.Forms.Label()
        ОкладLabel = New System.Windows.Forms.Label()
        CType(Me.РиелторскаяФирмаDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ДолжностиBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ДолжностиBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ДолжностиBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'НаимДолжностиLabel
        '
        НаимДолжностиLabel.AutoSize = True
        НаимДолжностиLabel.Location = New System.Drawing.Point(76, 72)
        НаимДолжностиLabel.Name = "НаимДолжностиLabel"
        НаимДолжностиLabel.Size = New System.Drawing.Size(99, 13)
        НаимДолжностиLabel.TabIndex = 3
        НаимДолжностиLabel.Text = "Наим Должности:"
        '
        'ОбязанностиLabel
        '
        ОбязанностиLabel.AutoSize = True
        ОбязанностиLabel.Location = New System.Drawing.Point(98, 108)
        ОбязанностиLabel.Name = "ОбязанностиLabel"
        ОбязанностиLabel.Size = New System.Drawing.Size(77, 13)
        ОбязанностиLabel.TabIndex = 4
        ОбязанностиLabel.Text = "Обязанности:"
        '
        'ТребованияLabel
        '
        ТребованияLabel.AutoSize = True
        ТребованияLabel.Location = New System.Drawing.Point(104, 148)
        ТребованияLabel.Name = "ТребованияLabel"
        ТребованияLabel.Size = New System.Drawing.Size(71, 13)
        ТребованияLabel.TabIndex = 6
        ТребованияLabel.Text = "Требования:"
        '
        'КодДолжностиLabel
        '
        КодДолжностиLabel.AutoSize = True
        КодДолжностиLabel.Location = New System.Drawing.Point(85, 228)
        КодДолжностиLabel.Name = "КодДолжностиLabel"
        КодДолжностиLabel.Size = New System.Drawing.Size(90, 13)
        КодДолжностиLabel.TabIndex = 8
        КодДолжностиLabel.Text = "Код Должности:"
        '
        'ОкладLabel
        '
        ОкладLabel.AutoSize = True
        ОкладLabel.Location = New System.Drawing.Point(133, 187)
        ОкладLabel.Name = "ОкладLabel"
        ОкладLabel.Size = New System.Drawing.Size(42, 13)
        ОкладLabel.TabIndex = 10
        ОкладLabel.Text = "Оклад:"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(74, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(260, 23)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Таблица ""Должности"""
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'РиелторскаяФирмаDataSet
        '
        Me.РиелторскаяФирмаDataSet.DataSetName = "РиелторскаяФирмаDataSet"
        Me.РиелторскаяФирмаDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ДолжностиBindingSource
        '
        Me.ДолжностиBindingSource.DataMember = "Должности"
        Me.ДолжностиBindingSource.DataSource = Me.РиелторскаяФирмаDataSet
        '
        'ДолжностиTableAdapter
        '
        Me.ДолжностиTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.UpdateOrder = РиэлторскаяФирма.РиелторскаяФирмаDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.ВидыКвартирTableAdapter = Nothing
        Me.TableAdapterManager.ВидыУслугTableAdapter = Nothing
        Me.TableAdapterManager.ДоговорыTableAdapter = Nothing
        Me.TableAdapterManager.ДолжностиTableAdapter = Me.ДолжностиTableAdapter
        Me.TableAdapterManager.Покупатели2TableAdapter = Nothing
        Me.TableAdapterManager.ПокупателиTableAdapter = Nothing
        Me.TableAdapterManager.ПродавцыTableAdapter = Nothing
        Me.TableAdapterManager.СотрудникиTableAdapter = Nothing
        '
        'ДолжностиBindingNavigator
        '
        Me.ДолжностиBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.ДолжностиBindingNavigator.BindingSource = Me.ДолжностиBindingSource
        Me.ДолжностиBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.ДолжностиBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.ДолжностиBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.ДолжностиBindingNavigatorSaveItem})
        Me.ДолжностиBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.ДолжностиBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.ДолжностиBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.ДолжностиBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.ДолжностиBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.ДолжностиBindingNavigator.Name = "ДолжностиBindingNavigator"
        Me.ДолжностиBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.ДолжностиBindingNavigator.Size = New System.Drawing.Size(391, 25)
        Me.ДолжностиBindingNavigator.TabIndex = 3
        Me.ДолжностиBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Добавить"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(43, 22)
        Me.BindingNavigatorCountItem.Text = "для {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Общее число элементов"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Удалить"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Переместить в начало"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Переместить назад"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Положение"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Текущее положение"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Переместить вперед"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Переместить в конец"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ДолжностиBindingNavigatorSaveItem
        '
        Me.ДолжностиBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ДолжностиBindingNavigatorSaveItem.Image = CType(resources.GetObject("ДолжностиBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.ДолжностиBindingNavigatorSaveItem.Name = "ДолжностиBindingNavigatorSaveItem"
        Me.ДолжностиBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.ДолжностиBindingNavigatorSaveItem.Text = "Сохранить данные"
        '
        'ОбязанностиTextBox
        '
        Me.ОбязанностиTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ДолжностиBindingSource, "Обязанности", True))
        Me.ОбязанностиTextBox.Location = New System.Drawing.Point(181, 105)
        Me.ОбязанностиTextBox.Name = "ОбязанностиTextBox"
        Me.ОбязанностиTextBox.Size = New System.Drawing.Size(198, 20)
        Me.ОбязанностиTextBox.TabIndex = 5
        '
        'ТребованияTextBox
        '
        Me.ТребованияTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ДолжностиBindingSource, "Требования", True))
        Me.ТребованияTextBox.Location = New System.Drawing.Point(181, 145)
        Me.ТребованияTextBox.Name = "ТребованияTextBox"
        Me.ТребованияTextBox.Size = New System.Drawing.Size(198, 20)
        Me.ТребованияTextBox.TabIndex = 7
        '
        'КодДолжностиTextBox
        '
        Me.КодДолжностиTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ДолжностиBindingSource, "КодДолжности", True))
        Me.КодДолжностиTextBox.Location = New System.Drawing.Point(181, 225)
        Me.КодДолжностиTextBox.Name = "КодДолжностиTextBox"
        Me.КодДолжностиTextBox.Size = New System.Drawing.Size(100, 20)
        Me.КодДолжностиTextBox.TabIndex = 9
        '
        'ОкладTextBox
        '
        Me.ОкладTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ДолжностиBindingSource, "Оклад", True))
        Me.ОкладTextBox.Location = New System.Drawing.Point(181, 184)
        Me.ОкладTextBox.Name = "ОкладTextBox"
        Me.ОкладTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ОкладTextBox.TabIndex = 11
        '
        'ComboBox1
        '
        Me.ComboBox1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.ДолжностиBindingSource, "КодДолжности", True))
        Me.ComboBox1.DataSource = Me.ДолжностиBindingSource
        Me.ComboBox1.DisplayMember = "НаимДолжности"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(181, 69)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 12
        Me.ComboBox1.ValueMember = "КодДолжности"
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(391, 325)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(ОкладLabel)
        Me.Controls.Add(Me.ОкладTextBox)
        Me.Controls.Add(КодДолжностиLabel)
        Me.Controls.Add(Me.КодДолжностиTextBox)
        Me.Controls.Add(ТребованияLabel)
        Me.Controls.Add(Me.ТребованияTextBox)
        Me.Controls.Add(ОбязанностиLabel)
        Me.Controls.Add(Me.ОбязанностиTextBox)
        Me.Controls.Add(НаимДолжностиLabel)
        Me.Controls.Add(Me.ДолжностиBindingNavigator)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form4"
        Me.Text = "Таблица ""Должности"""
        CType(Me.РиелторскаяФирмаDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ДолжностиBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ДолжностиBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ДолжностиBindingNavigator.ResumeLayout(False)
        Me.ДолжностиBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents РиелторскаяФирмаDataSet As РиелторскаяФирмаDataSet
    Friend WithEvents ДолжностиBindingSource As BindingSource
    Friend WithEvents ДолжностиTableAdapter As РиелторскаяФирмаDataSetTableAdapters.ДолжностиTableAdapter
    Friend WithEvents TableAdapterManager As РиелторскаяФирмаDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ДолжностиBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents ДолжностиBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents ОбязанностиTextBox As TextBox
    Friend WithEvents ТребованияTextBox As TextBox
    Friend WithEvents КодДолжностиTextBox As TextBox
    Friend WithEvents ОкладTextBox As TextBox
    Friend WithEvents ComboBox1 As ComboBox
End Class
